param(
    [string]$OutputDir,
    [string]$Version,
    [string]$Repo,
    [string]$Token,
    [string]$AppName = "LEHudModLauncher"
)

$ErrorActionPreference = "Stop"

Write-Host "=== Packaging release v$Version for $AppName ==="

# Paths
$OutputDir = "C:\modding\LE\LEHudModLauncher\Release\x64\Release\net9.0-windows"
#$OutputDir = $OutputDir.Trim('"')
$zipName = "LastEpochHudModLauncher.zip"
$zipPath = "C:\modding\LE\LEHudModLauncher\Release\LastEpochHudModLauncher.zip"
$updateJsonPath = Join-Path $OutputDir "update.json"
$baseUrl = "https://github.com/jpeaglesandkatz/LEHudModLauncher/releases/download/1.0"
$Token = $env:GITHUB_TOKEN

# Create ZIP
#if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Write-Host "Creating archive $zipName..."
Compress-Archive -Path (Join-Path $OutputDir "*") -DestinationPath $zipPath -Force

# Generate update.json
$generator = "C:\modding\LE\LEHudModLauncher\LEHudModLauncher\Tools\UpdateJsonGenerator.exe"
if (!(Test-Path $generator)) { throw "UpdateJsonGenerator.exe not found in $PSScriptRoot" }
& $generator 1.0 $zipPath $baseUrl

# Upload to GitHub Release
Write-Host "Checking release $Version on GitHub..."
$release = Invoke-RestMethod ' -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"} "https://api.github.com/repos/$Repo/releases/tags/$Version" -ErrorAction SilentlyContinue'

if (-not $release) {
    Write-Host "Creating release v$Version..."
    $body = @{ tag_name = "$Version"; name = "$Version"; draft = $false; prerelease = $false } | ConvertTo-Json
    $release = Invoke-RestMethod -Method POST `
        -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"} `
        -ContentType "application/json" -Body $body `
        "https://api.github.com/repos/$Repo/releases"
}

$releaseId = $release.id

# Upload assets
$assets = @($zipPath, $updateJsonPath)
foreach ($file in $assets) {
    $fileName = [IO.Path]::GetFileName($file)
    Write-Host "Uploading $fileName..."
    $url = "https://uploads.github.com/repos/$Repo/releases/$releaseId/assets?name=$fileName"

    # Delete if already exists
    foreach ($asset in $release.assets) {
        if ($asset.name -eq $fileName) {
            Write-Host "Deleting old $fileName..."
            Invoke-RestMethod -Method DELETE `
                -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"} `
                $asset.url
        }
    }

    Invoke-RestMethod -Method POST `
        -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"; "Content-Type" = "application/zip"} `
        -InFile $file `
        -Uri $url
}

Write-Host "✅ Release v$Version published successfully!"
