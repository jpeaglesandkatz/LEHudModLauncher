**Launcher / Installer for Last Epoch Hud Mod made by ASH**

Launcher by JP

Unrar the launcher archive somewhere on your computer and run the app

The Launcher requires .NET 9. I had to updrade to .NET 9 because .NET 6 is out of support and was giving way too many issues.  Both version 6 (required by the mod loader and the mod) and version 9 work perfectly fine next to eachother though.

__**Main reason for using the launcher:**__
- Easy install/reinstall of the mod launcher and mod, no manual putting newly commited files into place.
- Easy switching between online (no mods) and offline (hud mod enabled) play
- Integrated Melon loader log display with mod specific highlighting and easy to copy to clipboard for sharing with us in case there are issues.
- Frequently updated startup message (which will always display once no matter the setting if a newer message is downloaded). Startup message is automatically downloaded and will show mod update info and such.


