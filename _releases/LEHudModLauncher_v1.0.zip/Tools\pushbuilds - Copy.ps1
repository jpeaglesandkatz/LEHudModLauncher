param(
    [string]$OutputDir,
    [string]$Version,
    [string]$Repo,
    [string]$Token,
    [string]$AppName = "LEHudModLauncher"
)

$ErrorActionPreference = "Stop"

Write-Host "=== Packaging release v$Version for $AppName ==="

# Paths
$zipName = "$AppName-$Version.zip"
$zipPath = Join-Path $OutputDir $zipName
$updateJsonPath = Join-Path $OutputDir "update.json"
$baseUrl = "https://github.com/$Repo/releases/download/$Version"
$Token = "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"

# Create ZIP
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Write-Host "Creating archive $zipName..."
Compress-Archive -Path (Join-Path $OutputDir "*") -DestinationPath $zipPath -Force

# Generate update.json
$generator = Join-Path $PSScriptRoot "UpdateJsonGenerator.exe"
if (!(Test-Path $generator)) { throw "UpdateJsonGenerator.exe not found in $PSScriptRoot" }
& $generator $Version $zipPath $baseUrl

# Upload to GitHub Release
Write-Host "Checking release v$Version on GitHub..."
$release = Invoke-RestMethod `
    -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"} `
    "https://api.github.com/repos/$Repo/releases/tags/$Version" -ErrorAction SilentlyContinue

if (-not $release) {
    Write-Host "Creating release v$Version..."
    $body = @{ tag_name = "v$Version"; name = "$Version"; draft = $false; prerelease = $false } | ConvertTo-Json
    $release = Invoke-RestMethod -Method POST `
        -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"} `
        -ContentType "application/json" -Body $body `
        "https://api.github.com/repos/$Repo/releases"
}

$releaseId = $release.id

# Upload assets
$assets = @($zipPath, $updateJsonPath)
foreach ($file in $assets) {
    $fileName = [IO.Path]::GetFileName($file)
    Write-Host "Uploading $fileName..."
    $url = "https://uploads.github.com/repos/$Repo/releases/$releaseId/assets?name=$fileName"

    # Delete if already exists
    foreach ($asset in $release.assets) {
        if ($asset.name -eq $fileName) {
            Write-Host "Deleting old $fileName..."
            Invoke-RestMethod -Method DELETE `
                -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"} `
                $asset.url
        }
    }

    Invoke-RestMethod -Method POST `
        -Headers @{Authorization = "token $Token"; "User-Agent" = "PowerShell"; "Content-Type" = "application/zip"} `
        -InFile $file `
        -Uri $url
}

Write-Host "✅ Release v$Version published successfully!"
